using ScriptableObjects;

[System.Serializable]
public class WeaponDataWrapper
{
    public WeaponData weaponData;
}